<footer class="d-flex align-items-center justify-content-center bg-green">
  <div class="text-center hideInPrint">
    &copy; <?php echo date('Y') ?>. Ivy Tech Community College.<br />
    Fort Wayne Campus Tutoring Services - <a href="http://fwtutoringservices.com/" target="_blank">fwtutoringservices.com</a><br />
    Designed and developed by Blake Thurston, Matteo Catalano, Tim Tappan, Mark Spalding, and Jeremy Nally.
  </div>
</footer>
