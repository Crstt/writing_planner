var startDate = document.getElementById("startDate");
var dueDate = document.getElementById("dueDate");

flatpickr('#startDate');
flatpickr('#dueDate');

